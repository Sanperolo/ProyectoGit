

public interface ICalculator {

	public double add(double n1, double n2);
	
	public double subtract(double n1, double n2);
	
	public double multiply(double n1, double n2);
	
	public double divide(double n1, double n2);
	
	public double square(double n1);
	
	public double pow(double n1, double n2);
	
	public double sqrt(double n1);
	
	public double sqrt3(double n1);

}
