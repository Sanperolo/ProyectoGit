import org.junit.*;

import static org.mockito.Mockito.*;

public class CalServiceTest {
	
	CalService calService;
	@Before
	public void setup() {
		
		ICalculator cal = mock(ICalculator.class);
		
		when(cal.add(2.0, 5.25)).thenReturn(7.25);
		when(cal.subtract(5.0, 2.25)).thenReturn(2.75);
		when(cal.multiply(2.0, 5.25)).thenReturn(10.5);
		when(cal.divide(5.0, 2.0)).thenReturn(2.25);
		when(cal.square(5.25)).thenReturn(27.56);
		when(cal.pow(2.0, 3.0)).thenReturn(8.0);
		when(cal.sqrt(25.5)).thenReturn(5.04);
		when(cal.sqrt3(25.5)).thenReturn(2.94);
		
		calService = new CalService();
		calService.setCalc(cal);
		
	}
	
	@Test
	public void testAddTwoNumbers() {
		Assert.assertEquals(7.25, calService.AddTwoNumber(2.0, 5.25), 0.01);
	}
	
	@Test
	public void testSubtractTwoNumber() {
		Assert.assertEquals(2.75, calService.SubtractTwoNumber(5.0, 2.25), 0.01);
	}
	
	@Test
	public void testMultiplyTwoNumber() {
		Assert.assertEquals(10.5, calService.MultiplyTwoNumber(2.0, 5.25), 0.01);
	}
	
	@Test
	public void testDivideTwoNumbers() {
		Assert.assertEquals(2.25, calService.DivideTwoNumber(5.0, 2.0), 0.01);
	}
	
	@Test
	public void testSquareATwoNumbers() {
		Assert.assertEquals(27.56, calService.SquareANumber(5.25), 0.01);
	}
	
	@Test
	public void testPowNumbers() {
		Assert.assertEquals(8.0, calService.PowNumber(2.0, 3.0), 0.01);
	}
	
	@Test
	public void testSquareRoot() {
		Assert.assertEquals(5.04, calService.SquareRoot(25.5), 0.1);
	}
	
	@Test
	public void testCubeRoot() {
		Assert.assertEquals(2.94, calService.CubeRoot(25.5), 0.01);
	}
}
