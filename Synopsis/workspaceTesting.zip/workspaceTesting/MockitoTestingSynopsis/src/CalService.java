

public class CalService {
	
	ICalculator calc;
	
	public ICalculator getCalc() {
		return calc;
	}

	public void setCalc(ICalculator calc) {
		this.calc = calc;
	}
	
	public double AddTwoNumber (double n1, double n2) {
		return calc.add(n1, n2);
	}

	public double SubtractTwoNumber (double n1, double n2) {
		return calc.subtract(n1, n2);
	}
	
	public double MultiplyTwoNumber (double n1, double n2) {
		return calc.multiply(n1, n2);
	}
	
	public double DivideTwoNumber (double n1, double n2) {
		return calc.divide(n1, n2);
	}
	
	public double SquareANumber (double n1) {
		return calc.square(n1);
	}
	
	public double PowNumber (double n1, double n2) {
		return calc.pow(n1, n2);
	}
	
	public double SquareRoot (double n1) {
		return calc.sqrt(n1);
	}
	
	public double CubeRoot (double n1) {
		return calc.sqrt3(n1);
	}
}
