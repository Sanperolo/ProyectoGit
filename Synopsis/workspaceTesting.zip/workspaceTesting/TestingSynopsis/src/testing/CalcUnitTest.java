package testing;

import org.junit.Test;

import code.Calc;

import static org.junit.Assert.assertEquals;

import java.util.Locale;

public class CalcUnitTest {

	@Test
	public void testAdd() {
		double result = Calc.add(5.25, 2.0);
		assertEquals(7.25, result, 0.01);
	}

	@Test
	public void testSubtract() {
		double result = Calc.subtract(5.25, 2.0);
		assertEquals(3.25, result, 0.01);
	}

	@Test
	public void testMultiply() {
		double result = Calc.multiply(5.25, 2.0);
		assertEquals(10.5, result, 0.01);
	}

	@Test
	public void testDivide() {
		double result = Calc.divide(5.25, 2.0);
		assertEquals(2.625, result, 0.01);
	}

	@Test
	public void testSquare() {
		double result = Calc.square(5.25);
		assertEquals(27.56, result, 0.01);
	}

	@Test
	public void testPow() {
		double result = Calc.pow(5.25, 7.0);
		assertEquals(109929.721, result, 0.01);
	}

	@Test
	public void testSqrt() {
		double result = Calc.sqrt(5.25);
		assertEquals(2.291, result, 0.01);
	}

	@Test
	public void testSqrt3() {
		double result = Calc.sqrt3(5.25);
		assertEquals(1.73, result, 0.01);
	}

}
