package code;

public class Calc {

	public static double add(double n1, double n2) {
		return n1 + n2;		
	}
	
	public static double subtract(double n1, double n2) {
		return n1 - n2;
	}
	
	public static double multiply(double n1, double n2) {
		return n1 * n2;		
	}
	
	public static double divide(double n1, double n2) {
		return n1 / n2;
	}
	
	public static double square(double n1) {
		return n1 * n1;		
	}
	
	public static double pow(double n1, double n2) {
		return Math.pow(n1, n2);
	}
	
	public static double sqrt(double n1) {
		return Math.sqrt(n1);		
	}
	
	public static double sqrt3(double n1) {
		return Math.pow(n1,(1.0/3.0));
	}
	
}
