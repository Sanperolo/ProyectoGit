package code;
import java.util.Locale;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in).useLocale(Locale.US);
		String name;
		int n;
		double n1, n2;
		
		System.out.print("Hi, please enter you name:\t");
		name = sc.nextLine();

		System.out.print("\n"+name+" What Do you think to do?\n"
				+ "╔═══════════════════════════════╦═══════════════════════════════════════╦════════════════╗\n"
				+ "║1.Add (+)\t\t\t║2.Substract (-)\t\t\t║3.Multiply (*)  ║\n"
				+ "╠═══════════════════════════════╬═══════════════════════════════════════╬════════════════╣\n"
				+ "║4.Divide (÷)\t\t\t║5.Square (^2)\t\t\t\t║6.Exponents (^n)║\n"
				+ "╠═══════════════════════════════╬═══════════════════════════════════════╬════════════════╣\n"
				+ "║7.Square Root (√²)\t\t║8.Cube Root (√³)\t\t\t║9.EXIT          ║\n"
				+ "╠═════════════════CHOOSE AN OPTION BY TYPING THE NUMBER BY KEYBOARD═════╩════════════════╣\n"
				+ "╚════════════════════════════════════════════════════════════════════════════════════════╝\n\n"
				+ "─> ");
		n = sc.nextInt();
		
		switch (n) {
	        case 1: System.out.print(name+", you have choosen 1.Add (+)\nPlease, type the first number ─> ");
	        		n1 = sc.nextDouble();
	        		System.out.print(name+", please, type the second number ─> ");
	        		n2 = sc.nextDouble();
	        		System.out.print("The Result is ─> "+Calc.add(n1, n2));
	        		break;
	        case 2: System.out.print(name+", you have choosen 2.Substract (-)\nPlease, type the first number ─> ");
	        		n1 = sc.nextDouble();
	        		System.out.print(name+", please, type the second number ─> ");
	        		n2 = sc.nextDouble();
	        		System.out.print("The Result is ─> "+Calc.subtract(n1, n2));
	        		break;
	        case 3: System.out.print(name+", you have choosen 3.Multiply (*)\nPlease, type the first number ─> ");
					n1 = sc.nextDouble();
					System.out.print(name+", please, type the second number ─> ");
	        		n2 = sc.nextDouble();
	        		System.out.print("The Result is ─> "+Calc.multiply(n1, n2));
	                break;
	        case 4: System.out.print(name+", you have choosen 4.Divide (÷)\nPlease, type the first number ─> ");
					n1 = sc.nextDouble();
					System.out.print(name+", please, type the second number ─> ");
	        		n2 = sc.nextDouble();
	        		System.out.print("The Result is ─> "+Calc.divide(n1, n2));
	                break;
	        case 5: System.out.print(name+", you have choosen 5.Square (^2)\nPlease, type the number ─> ");
					n1 = sc.nextDouble();
					System.out.print("The Result is ─> "+Calc.square(n1));
					break;
	        case 6: System.out.print(name+", you have choosen 6.Exponents (^n)\nPlease, type the first number ─> ");
					n1 = sc.nextDouble();
					System.out.print(name+", please, type the second number ─> ");
	        		n2 = sc.nextDouble();
	        		System.out.print("The Result is ─> "+Calc.pow(n1, n2));
					break;
	        case 7: System.out.print(name+", you have choosen 7.Square Root (√²)\nPlease, type the number ─> ");
					n1 = sc.nextDouble();
					System.out.print("The Result is ─> "+Calc.sqrt(n1));
					break;
	        case 8: System.out.print(name+", you have choosen 8.Cube Root (√³)\nPlease, type the number ─> ");
					n1 = sc.nextDouble();
					System.out.print("The Result is ─> "+Calc.sqrt3(n1));
					break;
	        case 9: System.out.print(name+", you have choosen 9.EXIT \nSo... GOOD BYE!! ☺");
	        		break;
		}
		sc.close();
	}
}
